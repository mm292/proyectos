página web que nos muestra el tiempo actual de la ciudad de Madrid. Muestra:

Temperatura actual en ºC.

Temperatura minima y máxima en ºC del día.

Velocidad del viento.

Nubes

Volumen de lluvia de la ultima hora

Volumen de nieve de la ultima hora.



Además muestra la previsión del tiempo para los próximos 5 días.


