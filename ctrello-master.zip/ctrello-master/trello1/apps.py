from django.apps import AppConfig


class Trello1Config(AppConfig):
    name = 'trello1'
