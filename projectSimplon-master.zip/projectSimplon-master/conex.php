<?php

$link= mysqli_connect("localhost", "root", "", "simplon");
mysqli_set_charset($link, 'utf8');

?>