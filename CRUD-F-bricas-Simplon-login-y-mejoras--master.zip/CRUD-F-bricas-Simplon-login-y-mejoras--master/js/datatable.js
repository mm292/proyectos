$(document).ready(function () {
    
    $('#Example').DataTable({
    });
});//asi hacemos paginacion y orden y buscador 