from django.apps import AppConfig


class JuegoConfig(AppConfig):
    name = 'juego'
